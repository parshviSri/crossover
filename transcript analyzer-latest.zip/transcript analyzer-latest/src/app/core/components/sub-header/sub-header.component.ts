import {Component, TemplateRef} from '@angular/core';
import AgentFacade from 'src/app/core/facades/agent.facade';
import CallFacade from 'src/app/core/facades/call.facade';
import TemplateService from '../../services/template.service';
import {Router} from '@angular/router'; 
@Component({
  selector:    'app-gc-sub-header',
  templateUrl: './sub-header.component.html',
  styleUrls:   ['./sub-header.component.scss']
})
export default class SubHeaderComponent {
  agentValue:any=false;
  constructor(private _tplService: TemplateService,
    public agents: AgentFacade,
    public calls: CallFacade,
    private route:Router
    ) {
  }
  get content(): TemplateRef<any> | null {
    
    return this._tplService.get('subHeader') || null;
  }

  public selectAgent(event: any): void {
    this.agentValue=true
    this.agents.setActiveAgent(event.target?.value);
  };

  public selectCall(event: any): void {
    
    this.calls.selectCall(event.target?.value);
    this. route. navigate(['/analyzer'])
    console.log(this.calls.activeTranscript$ );
    
  }

}
